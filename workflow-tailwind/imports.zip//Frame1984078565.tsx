import svgPaths from "./svg-ldcyrv7b4u";

function CaretRight() {
  return (
    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <g id="CaretRight">
        <path d={svgPaths.p2e9abc80} fill="var(--fill-0, #CBD5E1)" id="Vector" />
      </g>
    </svg>
  );
}

function BreadcrumbIndicator() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Breadcrumb Indicator">
      <CaretRight />
    </div>
  );
}

function BreadcrumbLinkItem() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0" data-name="Breadcrumb Link Item">
      <div className="font-['Inter:Medium',_sans-serif] font-medium leading-[0] not-italic relative shrink-0 text-[12px] text-center text-nowrap text-slate-600 tracking-[-0.072px]">
        <p className="leading-[20px] whitespace-pre">Home</p>
      </div>
    </div>
  );
}

function BreadcrumbLinkItem1() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0" data-name="Breadcrumb Link Item">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-center text-nowrap text-slate-600" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[1.5] whitespace-pre">Workflow</p>
      </div>
    </div>
  );
}

function CaretRight3() {
  return (
    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <g id="CaretRight"></g>
    </svg>
  );
}

function BreadcrumbIndicator3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Breadcrumb Indicator">
      <CaretRight3 />
    </div>
  );
}

function BreadcrumbLinkGroup() {
  return (
    <div className="content-stretch flex gap-[2px] items-center justify-start relative shrink-0" data-name="Breadcrumb Link Group">
      <BreadcrumbIndicator />
      <BreadcrumbLinkItem />
      <BreadcrumbIndicator />
      <BreadcrumbLinkItem1 />
      <BreadcrumbIndicator />
      <BreadcrumbIndicator3 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] items-start justify-center relative shrink-0" data-name="Frame">
      <BreadcrumbLinkGroup />
    </div>
  );
}

function Frame1984078277() {
  return (
    <div className="content-stretch flex flex-col gap-[11px] items-start justify-start relative shrink-0 w-full">
      <Frame />
    </div>
  );
}

function Frame1984078544() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[14px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[1.2] whitespace-pre">Quick Actions</p>
      </div>
      <div className="flex h-[5px] items-center justify-center relative shrink-0 w-[9px]">
        <div className="flex-none rotate-[270deg]">
          <div className="h-[9px] relative w-[5px]" data-name="Arrow down">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 9">
              <path clipRule="evenodd" d={svgPaths.p8b14d80} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Add2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="add_2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="add_2">
          <mask height="24" id="mask0_1_1552" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="24" x="0" y="0">
            <rect fill="var(--fill-0, #D9D9D9)" height="24" id="Bounding box" width="24" />
          </mask>
          <g mask="url(#mask0_1_1552)">
            <path d={svgPaths.p3ad56700} fill="var(--fill-0, black)" id="add_2_2" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function PrimaryButton() {
  return (
    <div className="box-border content-stretch flex gap-[10px] items-center justify-center px-[16px] py-[8px] relative rounded-[8px] self-stretch shrink-0" data-name="Primary button">
      <div aria-hidden="true" className="absolute border border-[#e4e4e5] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      <Add2 />
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px] whitespace-pre">Create Workflow</p>
      </div>
    </div>
  );
}

function Frame1984078171() {
  return (
    <div className="content-stretch flex gap-[16px] items-start justify-start relative shrink-0">
      <PrimaryButton />
    </div>
  );
}

function Frame1984078203() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-center justify-start relative shrink-0">
      <Frame1984078171 />
    </div>
  );
}

function Frame1984078346() {
  return (
    <div className="content-stretch flex gap-[8px] h-[40px] items-start justify-start relative shrink-0">
      <Frame1984078203 />
    </div>
  );
}

function InvoiceContractActivityLog() {
  return (
    <div className="bg-white relative rounded-[4px] shrink-0 w-full" data-name="INVOICE / CONTRACT / ACTIVITY LOG">
      <div aria-hidden="true" className="absolute border border-[#e4e4e5] border-solid inset-[-1px] pointer-events-none rounded-[5px]" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[8px] relative w-full">
          <Frame1984078544 />
          <Frame1984078346 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078242() {
  return (
    <div className="content-stretch flex flex-col gap-[11px] items-start justify-start relative shrink-0 w-[94px]">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Workflows</p>
      </div>
    </div>
  );
}

function HospitalIcon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Hospital icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_1542)" id="Hospital icon">
          <g id="Vector"></g>
          <path d="M3 21H21" id="Vector_2" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p21295e40} id="Vector_3" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p6e25500} id="Vector_4" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10 9H14" id="Vector_5" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 7V11" id="Vector_6" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_1542">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function TeamFilled() {
  return (
    <div className="bg-white box-border content-stretch flex gap-[10px] items-start justify-start p-[6px] relative rounded-[8px] shrink-0" data-name="Team filled">
      <HospitalIcon />
    </div>
  );
}

function Frame1984078243() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start leading-[0] relative shrink-0 text-black w-[150px]">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium relative shrink-0 text-[14px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[1.2]">
          All w
          <span className="font-['Roboto:Medium',_sans-serif] font-medium" style={{ fontVariationSettings: "'wdth' 100" }}>
            orkflows
          </span>
        </p>
      </div>
      <div className="font-['Roboto:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal]">20</p>
      </div>
    </div>
  );
}

function Frame1984078274() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-start relative shrink-0 w-full">
      <TeamFilled />
      <Frame1984078243 />
    </div>
  );
}

function Card() {
  return (
    <div className="bg-white box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[8px] relative rounded-[8px] shrink-0" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[#e4e4e5] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Frame1984078274 />
    </div>
  );
}

function HospitalIcon1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Hospital icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_1542)" id="Hospital icon">
          <g id="Vector"></g>
          <path d="M3 21H21" id="Vector_2" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p21295e40} id="Vector_3" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p6e25500} id="Vector_4" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10 9H14" id="Vector_5" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 7V11" id="Vector_6" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_1542">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function TeamFilled1() {
  return (
    <div className="bg-white box-border content-stretch flex gap-[10px] items-start justify-start p-[6px] relative rounded-[8px] shrink-0" data-name="Team filled">
      <HospitalIcon1 />
    </div>
  );
}

function Frame1984078244() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start leading-[0] relative shrink-0 text-black w-[150px]">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium relative shrink-0 text-[14px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[1.2]">Workflows active</p>
      </div>
      <div className="font-['Roboto:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal]">10</p>
      </div>
    </div>
  );
}

function Frame1984078275() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-start relative shrink-0 w-full">
      <TeamFilled1 />
      <Frame1984078244 />
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-white box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[8px] relative rounded-[8px] shrink-0" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[#e4e4e5] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Frame1984078275 />
    </div>
  );
}

function HospitalIcon2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Hospital icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_1542)" id="Hospital icon">
          <g id="Vector"></g>
          <path d="M3 21H21" id="Vector_2" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p21295e40} id="Vector_3" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p6e25500} id="Vector_4" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10 9H14" id="Vector_5" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 7V11" id="Vector_6" stroke="var(--stroke-0, #0F4977)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_1542">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function TeamFilled2() {
  return (
    <div className="bg-white box-border content-stretch flex gap-[10px] items-start justify-start p-[6px] relative rounded-[8px] shrink-0" data-name="Team filled">
      <HospitalIcon2 />
    </div>
  );
}

function Frame1984078246() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start leading-[0] relative shrink-0 text-black w-[150px]">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium relative shrink-0 text-[14px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[1.2]">Workflow Draft</p>
      </div>
      <div className="font-['Roboto:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] w-full" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal]">10</p>
      </div>
    </div>
  );
}

function Frame1984078278() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-start relative shrink-0 w-full">
      <TeamFilled2 />
      <Frame1984078246 />
    </div>
  );
}

function Card2() {
  return (
    <div className="bg-white box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[8px] relative rounded-[8px] shrink-0" data-name="Card">
      <div aria-hidden="true" className="absolute border border-[#e4e4e5] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Frame1984078278 />
    </div>
  );
}

function Frame1984078276() {
  return (
    <div className="content-stretch flex gap-[16px] items-center justify-start relative shrink-0 w-full">
      <Card />
      <Card1 />
      <Card2 />
    </div>
  );
}

function Frame1984078567() {
  return (
    <div className="bg-white box-border content-stretch flex flex-col gap-[8px] items-start justify-center px-[8px] py-[16px] relative rounded-[8px] shrink-0 w-[966px]">
      <Frame1984078242 />
      <Frame1984078276 />
    </div>
  );
}

function SearchIcon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Search icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Search icon">
          <path d={svgPaths.p272bfa00} id="Icon" stroke="var(--stroke-0, #121215)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Left() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-start relative shrink-0" data-name="Left">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(18,18,21,0.3)] text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[1.2] whitespace-pre">Quick Search</p>
      </div>
    </div>
  );
}

function Search() {
  return (
    <div className="bg-white box-border content-stretch flex gap-[14px] h-[38px] items-center justify-start px-[16px] py-[12px] relative rounded-[8px] shrink-0 w-[309px]" data-name="Search">
      <div aria-hidden="true" className="absolute border border-[rgba(18,18,21,0.1)] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <SearchIcon />
      <Left />
    </div>
  );
}

function Filter() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Filter">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_1563)" id="Filter">
          <g id="Vector"></g>
          <path d={svgPaths.p1bcd6b80} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_1563">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function PrimaryButton1() {
  return (
    <div className="bg-white box-border content-stretch flex gap-[10px] h-[39px] items-center justify-center px-[16px] py-[8px] relative rounded-[8px] shrink-0" data-name="Primary button">
      <div aria-hidden="true" className="absolute border border-[rgba(18,18,21,0.3)] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      <Filter />
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[16px] whitespace-pre">Filter</p>
      </div>
    </div>
  );
}

function Frame1984078268() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] h-[55px] relative rounded-tl-[8px] rounded-tr-[8px] shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[55px] items-center justify-between p-[8px] relative w-full">
          <Search />
          <PrimaryButton1 />
        </div>
      </div>
    </div>
  );
}

function ShowText() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0" data-name="show text">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center justify-center px-[24px] py-0 relative size-full">
          <div className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[14px] text-black text-center text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[1.2] whitespace-pre">Workflows Name</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function HdCells() {
  return (
    <div className="bg-[#f3faff] h-[44px] relative shrink-0 w-full" data-name=".HD Cells">
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[44px] items-center justify-center px-[8px] py-[13px] relative w-full">
          <ShowText />
        </div>
      </div>
    </div>
  );
}

function DataCells() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-start px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#0f4977] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">MFA_LINE_NBR Flow</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells1() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#0f4977] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">Created_By_Id Flow</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells2() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#0f4977] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">RPTG_CLAIM_IFM_TYPE_CD Flow</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells3() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#0f4977] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span>{`FIN_BUS_SEGMENT_CD `}</span>Flow
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells4() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#0f4977] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span>{`Oracle_Fin_Bus_Seg_CD `}</span>Flow
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells5() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#0f4977] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span>{`Bundle Logic `}</span>Flow
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells6() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#0f4977] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span>{` Journal_Type_CD `}</span>Flow
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells7() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#0f4977] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span>{` Hospital - Sunrise `}</span>Flow
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells8() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#0f4977] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span>{`Statewide `}</span>Flow
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1984078163() {
  return (
    <div className="content-stretch flex flex-col h-[454px] items-start justify-start relative shrink-0 w-[172px]">
      <HdCells />
      <DataCells />
      <DataCells1 />
      <DataCells2 />
      <DataCells3 />
      <DataCells4 />
      <DataCells5 />
      <DataCells6 />
      <DataCells7 />
      <DataCells8 />
    </div>
  );
}

function ShowText1() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0" data-name="show text">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center justify-center px-[24px] py-0 relative size-full">
          <div className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[14px] text-black text-center w-[105px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[1.2]">Description</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function HdCells1() {
  return (
    <div className="bg-[#f3faff] h-[44px] relative shrink-0 w-full" data-name=".HD Cells">
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[44px] items-center justify-center px-[8px] py-[13px] relative w-full">
          <ShowText1 />
        </div>
      </div>
    </div>
  );
}

function DataCells9() {
  return (
    <div className="bg-white h-[51px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[51px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">This is for validating multiple conditions associated with MFA Line Number column</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells10() {
  return (
    <div className="bg-white h-[52px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[52px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">This is for validating multiple conditions associated with Category column</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells11() {
  return (
    <div className="bg-white h-[51px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[51px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">This is for validating multiple conditions associated with RPTG_CLAIM_IFM_TYPE_CD column</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells12() {
  return (
    <div className="bg-white h-[51px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[51px] items-center justify-start px-[8px] py-[4px] relative w-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">This is for validating multiple conditions associated with FIN_BUS_SEGMENT_CD column</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells13() {
  return (
    <div className="bg-white h-[51px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[51px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">This is for validating multiple conditions associated with Oracle_Fin_Bus_Seg_CD column</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells14() {
  return (
    <div className="bg-white h-[52px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[52px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">This is for validating multiple conditions associated with Journal_Type_CD column</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells15() {
  return (
    <div className="bg-white h-[51px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[51px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">This is for validating multiple conditions associated with Low_Income_Subsidy_CD column</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells16() {
  return (
    <div className="bg-white h-[51px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[51px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">Reviews audit trail entries for compliance and accuracy.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1984078179() {
  return (
    <div className="content-stretch flex flex-col h-[461px] items-start justify-start relative shrink-0 w-[353px]">
      <HdCells1 />
      <DataCells9 />
      <DataCells10 />
      <DataCells11 />
      <DataCells12 />
      <DataCells13 />
      <DataCells14 />
      <DataCells15 />
      <DataCells16 />
    </div>
  );
}

function ShowText2() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0" data-name="show text">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center justify-center px-[24px] py-0 relative size-full">
          <div className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[14px] text-black text-center w-[105px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[1.2]">Status</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function HdCells2() {
  return (
    <div className="bg-[#f3faff] h-[44px] relative shrink-0 w-full" data-name=".HD Cells">
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[44px] items-center justify-center px-[8px] py-[13px] relative w-full">
          <ShowText2 />
        </div>
      </div>
    </div>
  );
}

function Badge() {
  return (
    <div className="bg-[rgba(179,38,30,0.1)] box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative rounded-[16px] shrink-0" data-name="Badge">
      <div aria-hidden="true" className="absolute border-0 border-[#b3261e] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#b3261e] text-[12px] text-center text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[12px] whitespace-pre">Inactive</p>
      </div>
    </div>
  );
}

function DataCells17() {
  return (
    <div className="bg-white h-[51px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[51px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <Badge />
        </div>
      </div>
    </div>
  );
}

function Badge1() {
  return (
    <div className="bg-[rgba(76,175,80,0.1)] box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative rounded-[16px] shrink-0" data-name="Badge">
      <div aria-hidden="true" className="absolute border-0 border-[#4caf50] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#4caf50] text-[12px] text-center text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[12px] whitespace-pre">Active</p>
      </div>
    </div>
  );
}

function DataCells18() {
  return (
    <div className="bg-white h-[52px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[52px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <Badge1 />
        </div>
      </div>
    </div>
  );
}

function Badge2() {
  return (
    <div className="bg-[rgba(76,175,80,0.1)] box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative rounded-[16px] shrink-0" data-name="Badge">
      <div aria-hidden="true" className="absolute border-0 border-[#4caf50] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#4caf50] text-[12px] text-center text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[12px] whitespace-pre">Active</p>
      </div>
    </div>
  );
}

function DataCells19() {
  return (
    <div className="bg-white h-[51px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[51px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <Badge2 />
        </div>
      </div>
    </div>
  );
}

function Badge8() {
  return (
    <div className="bg-[#f3faff] box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative rounded-[16px] shrink-0" data-name="Badge">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#0f4977] text-[12px] text-center text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[12px] whitespace-pre">Validate</p>
      </div>
      <div className="h-[9.333px] relative shrink-0 w-[7.333px]" data-name="icon">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 10">
          <path d={svgPaths.p39fb1e80} fill="var(--fill-0, #0F4977)" id="icon" />
        </svg>
      </div>
    </div>
  );
}

function DataCells25() {
  return (
    <div className="bg-white h-[52px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[52px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <Badge8 />
        </div>
      </div>
    </div>
  );
}

function Badge9() {
  return (
    <div className="bg-[#f3faff] box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative rounded-[16px] shrink-0" data-name="Badge">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#0f4977] text-[12px] text-center text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[12px] whitespace-pre">Validate</p>
      </div>
      <div className="h-[9.333px] relative shrink-0 w-[7.333px]" data-name="icon">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 10">
          <path d={svgPaths.p39fb1e80} fill="var(--fill-0, #0F4977)" id="icon" />
        </svg>
      </div>
    </div>
  );
}

function DataCells26() {
  return (
    <div className="bg-white h-[51px] relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex h-[51px] items-center justify-between px-[8px] py-[4px] relative w-full">
          <Badge9 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078185() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow h-full items-start justify-start min-h-px min-w-px relative shrink-0">
      <HdCells2 />
      <DataCells17 />
      <DataCells18 />
      <DataCells19 />
      <DataCells17 />
      <DataCells19 />
      <DataCells19 />
      <DataCells19 />
      <DataCells19 />
      <DataCells25 />
      <DataCells26 />
      <DataCells19 />
    </div>
  );
}

function ShowText3() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0" data-name="show text">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center justify-center px-[24px] py-0 relative size-full">
          <div className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[14px] text-black text-center w-[105px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[1.2]">Created by</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function HdCells3() {
  return (
    <div className="bg-[#f3faff] h-[44px] relative shrink-0 w-full" data-name=".HD Cells">
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[44px] items-center justify-center px-[8px] py-[13px] relative w-full">
          <ShowText3 />
        </div>
      </div>
    </div>
  );
}

function DataCells28() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">{`User A `}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells30() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">User B</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells31() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">User C</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells32() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">User D</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1984078186() {
  return (
    <div className="content-stretch flex flex-col h-[461px] items-center justify-center relative shrink-0 w-[81px]">
      <HdCells3 />
      <DataCells28 />
      <DataCells28 />
      <DataCells30 />
      <DataCells31 />
      {[...Array(3).keys()].map((_, i) => (
        <DataCells32 key={i} />
      ))}
      <DataCells28 />
    </div>
  );
}

function ShowText4() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0" data-name="show text">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center justify-center px-[24px] py-0 relative size-full">
          <div className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[14px] text-black text-center text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[1.2] whitespace-pre">GIT</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function HdCells4() {
  return (
    <div className="bg-[#f3faff] h-[44px] relative shrink-0 w-full" data-name=".HD Cells">
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[44px] items-center justify-center px-[8px] py-[13px] relative w-full">
          <ShowText4 />
        </div>
      </div>
    </div>
  );
}

function DataCells36() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">V1</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells37() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">V2</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells39() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">V3</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1984078190() {
  return (
    <div className="content-stretch flex flex-col h-[461px] items-center justify-center relative shrink-0 w-[81px]">
      <HdCells4 />
      <DataCells36 />
      <DataCells37 />
      <DataCells37 />
      <DataCells39 />
      <DataCells37 />
      <DataCells37 />
      <DataCells37 />
      <DataCells37 />
    </div>
  );
}

function ShowText5() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0" data-name="show text">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center justify-center px-[24px] py-0 relative size-full">
          <div className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[14px] text-black text-center w-[105px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[1.2]">Used In</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function HdCells5() {
  return (
    <div className="bg-[#f3faff] h-[44px] relative shrink-0 w-full" data-name=".HD Cells">
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[44px] items-center justify-center px-[8px] py-[13px] relative w-full">
          <ShowText5 />
        </div>
      </div>
    </div>
  );
}

function DataCells44() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span className="font-['Roboto:SemiBold',_sans-serif] font-semibold text-[#0f4977]" style={{ fontVariationSettings: "'wdth' 100" }}>
                3
              </span>
              <span>{` Queues`}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells45() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span className="font-['Roboto:SemiBold',_sans-serif] font-semibold text-[#0f4977]" style={{ fontVariationSettings: "'wdth' 100" }}>
                4
              </span>
              <span>{` Queues`}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells47() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span className="font-['Roboto:SemiBold',_sans-serif] font-semibold text-[#0f4977]" style={{ fontVariationSettings: "'wdth' 100" }}>
                5
              </span>
              <span>{` Queues`}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells48() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span className="font-['Roboto:SemiBold',_sans-serif] font-semibold text-[#0f4977]" style={{ fontVariationSettings: "'wdth' 100" }}>
                6
              </span>
              <span>{` Queues`}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function DataCells49() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <div className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#1d2433] text-[14px] text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[20px]">
              <span className="font-['Roboto:SemiBold',_sans-serif] font-semibold text-[#0f4977]" style={{ fontVariationSettings: "'wdth' 100" }}>
                7
              </span>
              <span>{` Queues`}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame1984078189() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow h-[461px] items-center justify-center min-h-px min-w-px relative shrink-0">
      <HdCells5 />
      <DataCells44 />
      {[...Array(2).keys()].map((_, i) => (
        <DataCells45 key={i} />
      ))}
      <DataCells47 />
      <DataCells48 />
      {[...Array(3).keys()].map((_, i) => (
        <DataCells49 key={i} />
      ))}
    </div>
  );
}

function ShowText6() {
  return (
    <div className="basis-0 grow h-full min-h-px min-w-px relative shrink-0" data-name="show text">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center justify-center px-[24px] py-0 relative size-full">
          <div className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[14px] text-black text-center w-[105px]" style={{ fontVariationSettings: "'wdth' 100" }}>
            <p className="leading-[1.2]">Actions</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function HdCells6() {
  return (
    <div className="bg-[#f3faff] h-[44px] relative shrink-0 w-full" data-name=".HD Cells">
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none" />
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] h-[44px] items-center justify-center px-[8px] py-[13px] relative w-full">
          <ShowText6 />
        </div>
      </div>
    </div>
  );
}

function Frame163068() {
  return (
    <div className="relative shrink-0 size-[30.582px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31 31">
        <g id="Frame 163068">
          <path d={svgPaths.p10246370} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function DataCells52() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0 w-full" data-name=".Data Cells">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-center px-[8px] py-[4px] relative size-full">
          <Frame163068 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078187() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow h-[461px] items-start justify-start min-h-px min-w-px relative shrink-0">
      <HdCells6 />
      {[...Array(8).keys()].map((_, i) => (
        <DataCells52 key={i} />
      ))}
    </div>
  );
}

function Scrollbar() {
  return (
    <div className="absolute h-[670px] left-[1856.17px] overflow-clip top-[48px] w-[8px]" data-name="Scrollbar">
      <div className="absolute bg-[#e4e4e5] bottom-0 right-[4px] rounded-[100px] top-0 w-[4px]" data-name="Scrollbar" />
      <div className="absolute bg-[#79747e] bottom-[563px] right-[4px] rounded-[100px] top-[2px] w-[4px]" data-name="Scrollbar" />
    </div>
  );
}

function Scrollbar1() {
  return (
    <div className="bg-white h-[1165px] overflow-clip relative w-[15px]" data-name="Scrollbar">
      <div className="absolute bg-[#e4e4e5] bottom-[7px] right-[4px] rounded-[100px] top-0 w-[4px]" data-name="Scrollbar" />
      <div className="absolute bg-[#79747e] bottom-[563px] right-[4px] rounded-[100px] top-[2px] w-[4px]" data-name="Scrollbar" />
    </div>
  );
}

function Frame1984078245() {
  return (
    <div className="h-[461px] relative shrink-0 w-full">
      <div className="content-stretch flex h-[461px] items-start justify-start overflow-clip relative w-full">
        <Frame1984078163 />
        <Frame1984078179 />
        <Frame1984078185 />
        <Frame1984078186 />
        <Frame1984078190 />
        <Frame1984078189 />
        <Frame1984078187 />
        <Scrollbar />
        <div className="absolute flex h-[15px] items-center justify-center left-[11px] top-[446px] w-[1165px]">
          <div className="flex-none rotate-[270deg]">
            <Scrollbar1 />
          </div>
        </div>
      </div>
      <div aria-hidden="true" className="absolute border border-[rgba(18,18,21,0.1)] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Frame1984078551() {
  return (
    <div className="content-stretch flex flex-col items-start justify-start relative shrink-0 w-full">
      <Frame1984078268 />
      <Frame1984078245 />
    </div>
  );
}

export default function Frame1984078565() {
  return (
    <div className="bg-white relative size-full">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[16px] items-start justify-start p-[16px] relative size-full">
          <Frame1984078277 />
          <InvoiceContractActivityLog />
          <Frame1984078567 />
          <Frame1984078551 />
        </div>
      </div>
    </div>
  );
}