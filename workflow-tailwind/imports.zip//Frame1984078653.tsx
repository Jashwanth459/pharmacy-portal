import svgPaths from "./svg-93yvdn64qj";
import imgFillColor from "figma:asset/090062a106e411378fba9b1e82a7513a1972d53f.png";
import imgImage15 from "figma:asset/6a49a27ddb979620bdaaef9a45cf0ecfd6ff20a7.png";
import imgColorDropper from "figma:asset/bc813535f83f0e35db566e10a632b94c4afe4392.png";

function CaretRight() {
  return (
    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <g id="CaretRight">
        <path d={svgPaths.p2e9abc80} fill="var(--fill-0, #CBD5E1)" id="Vector" />
      </g>
    </svg>
  );
}

function BreadcrumbIndicator() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Breadcrumb Indicator">
      <CaretRight />
    </div>
  );
}

function BreadcrumbLinkItem() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0" data-name="Breadcrumb Link Item">
      <div className="font-['Inter:Medium',_sans-serif] font-medium leading-[0] not-italic relative shrink-0 text-[12px] text-center text-nowrap text-slate-600 tracking-[-0.072px]">
        <p className="leading-[20px] whitespace-pre">Home</p>
      </div>
    </div>
  );
}

function BreadcrumbLinkItem1() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0" data-name="Breadcrumb Link Item">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-center text-nowrap text-slate-600" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[1.5] whitespace-pre">Workflow</p>
      </div>
    </div>
  );
}

function BreadcrumbLinkItem2() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0" data-name="Breadcrumb Link Item">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-center text-nowrap text-slate-600" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[1.5] whitespace-pre">Create Workflow</p>
      </div>
    </div>
  );
}

function CaretRight3() {
  return (
    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
      <g id="CaretRight"></g>
    </svg>
  );
}

function BreadcrumbIndicator3() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Breadcrumb Indicator">
      <CaretRight3 />
    </div>
  );
}

function BreadcrumbLinkGroup() {
  return (
    <div className="content-stretch flex gap-[2px] items-center justify-start relative shrink-0" data-name="Breadcrumb Link Group">
      <BreadcrumbIndicator />
      <BreadcrumbLinkItem />
      <BreadcrumbIndicator />
      <BreadcrumbLinkItem1 />
      <BreadcrumbIndicator />
      <BreadcrumbLinkItem2 />
      <BreadcrumbIndicator3 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] items-start justify-center relative shrink-0" data-name="Frame">
      <BreadcrumbLinkGroup />
    </div>
  );
}

function Frame1984078277() {
  return (
    <div className="content-stretch flex flex-col gap-[11px] items-start justify-start relative shrink-0 w-full">
      <Frame />
    </div>
  );
}

function Frame1984078558() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">File</p>
      </div>
    </div>
  );
}

function ArrowDown() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 5">
        <g id="Arrow down"></g>
      </svg>
    </div>
  );
}

function Frame1984078559() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-full">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-center pl-[16px] pr-[8px] py-[8px] relative size-full">
          <Frame1984078558 />
          <ArrowDown />
        </div>
      </div>
    </div>
  );
}

function RulesBox() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] box-border content-stretch flex flex-col gap-[8px] h-full items-start justify-start p-[10px] relative shrink-0" data-name="Rules box">
      <Frame1984078559 />
    </div>
  );
}

function Frame1984078562() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Edit</p>
      </div>
    </div>
  );
}

function ArrowDown1() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 5">
        <g id="Arrow down"></g>
      </svg>
    </div>
  );
}

function Frame1984078564() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-full">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-center pl-[16px] pr-[8px] py-[8px] relative size-full">
          <Frame1984078562 />
          <ArrowDown1 />
        </div>
      </div>
    </div>
  );
}

function RulesBox1() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] box-border content-stretch flex flex-col gap-[8px] h-full items-start justify-start p-[10px] relative shrink-0" data-name="Rules box">
      <Frame1984078564 />
    </div>
  );
}

function Frame1984078565() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">View</p>
      </div>
    </div>
  );
}

function ArrowDown2() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 5">
        <g id="Arrow down"></g>
      </svg>
    </div>
  );
}

function Frame1984078566() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-full">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-center pl-[16px] pr-[8px] py-[8px] relative size-full">
          <Frame1984078565 />
          <ArrowDown2 />
        </div>
      </div>
    </div>
  );
}

function RulesBox2() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] box-border content-stretch flex flex-col gap-[8px] h-full items-start justify-start p-[10px] relative shrink-0" data-name="Rules box">
      <Frame1984078566 />
    </div>
  );
}

function Frame1984078567() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Extras</p>
      </div>
    </div>
  );
}

function Frame1984078568() {
  return (
    <div className="basis-0 box-border content-stretch flex gap-[6px] grow items-center justify-center min-h-px min-w-px px-0 py-[8px] relative shrink-0 w-[66px]">
      <Frame1984078567 />
    </div>
  );
}

function RulesBox3() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] box-border content-stretch flex flex-col gap-[8px] h-full items-start justify-start p-[10px] relative shrink-0" data-name="Rules box">
      <Frame1984078568 />
    </div>
  );
}

function Frame1984078569() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">AI</p>
      </div>
    </div>
  );
}

function Frame1984078570() {
  return (
    <div className="basis-0 box-border content-stretch flex gap-[6px] grow items-center justify-center min-h-px min-w-px px-0 py-[8px] relative shrink-0 w-[66px]">
      <Frame1984078569 />
    </div>
  );
}

function RulesBox4() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] box-border content-stretch flex flex-col gap-[8px] h-full items-start justify-start p-[10px] relative shrink-0" data-name="Rules box">
      <Frame1984078570 />
    </div>
  );
}

function Frame1984078651() {
  return (
    <div className="content-stretch flex h-[45px] items-start justify-start relative shrink-0 w-[296px]">
      <RulesBox />
      <RulesBox1 />
      <RulesBox2 />
      <RulesBox3 />
      <RulesBox4 />
    </div>
  );
}

function Frame1984078654() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] content-stretch flex flex-col gap-[10px] items-start justify-start relative shrink-0 w-full">
      <Frame1984078651 />
    </div>
  );
}

function ArStickers() {
  return (
    <div className="h-[19.387px] relative shrink-0 w-[23.825px]" data-name="Ar stickers">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 20">
        <g id="Ar stickers">
          <path d={svgPaths.p1e3d3500} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function ArStickers1() {
  return (
    <div className="h-[19.387px] relative w-[23.825px]" data-name="Ar stickers">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 20">
        <g id="Ar stickers">
          <path d={svgPaths.p1e3d3500} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function ZoomIn() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Zoom in">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_2219)" id="Zoom in">
          <g id="Vector"></g>
          <path d={svgPaths.p15861e40} fill="var(--fill-0, black)" id="Vector_2" />
          <path d={svgPaths.p1d020f00} fill="var(--fill-0, black)" id="Vector_3" />
        </g>
        <defs>
          <clipPath id="clip0_1_2219">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame1984078622() {
  return (
    <div className="box-border content-stretch flex gap-[6px] items-center justify-start p-[8px] relative rounded-[8px] shrink-0">
      <ZoomIn />
    </div>
  );
}

function Frame1984078623() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1984078623">
          <path d={svgPaths.p1f2ea2c0} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Frame1984078658() {
  return (
    <div className="content-stretch flex gap-[40px] items-center justify-start relative shrink-0">
      <ArStickers />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <ArStickers1 />
        </div>
      </div>
      <Frame1984078622 />
      <Frame1984078623 />
    </div>
  );
}

function Frame1984078649() {
  return (
    <div className="bg-white box-border content-stretch flex gap-[10px] items-start justify-start p-[4px] relative shrink-0">
      <div aria-hidden="true" className="absolute border border-[#e4e4e5] border-solid inset-0 pointer-events-none" />
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">30 %</p>
      </div>
    </div>
  );
}

function RulesBox5() {
  return (
    <div className="h-[45px] relative shrink-0 w-[44px]" data-name="Rules box">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 44 45">
        <g id="Rules box">
          <rect fill="#E4E4E5" fillOpacity="0.2" height="45" width="44" />
          <path d={svgPaths.p1b0adc00} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function RulesBox6() {
  return (
    <div className="h-[45px] relative shrink-0 w-[40px]" data-name="Rules box">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 45">
        <g id="Rules box">
          <rect fill="#E4E4E5" fillOpacity="0.2" height="45" width="40" />
          <path d={svgPaths.pd9c2900} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function RulesBox7() {
  return (
    <div className="h-[45px] relative shrink-0 w-[40px]" data-name="Rules box">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 45">
        <g id="Rules box">
          <rect fill="#E4E4E5" fillOpacity="0.2" height="45" width="40" />
          <path d={svgPaths.p55c8c00} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function RulesBox8() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] box-border content-stretch flex flex-col gap-[8px] h-[45px] items-start justify-center p-[10px] relative shrink-0" data-name="Rules box">
      <div className="bg-center bg-contain bg-no-repeat shrink-0 size-[24px]" data-name="Fill Color" style={{ backgroundImage: `url('${imgFillColor}')` }} />
    </div>
  );
}

function ContentCopy() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Content copy">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_2203)" id="Content copy">
          <g id="Vector"></g>
          <path d={svgPaths.pfd4db00} fill="var(--fill-0, black)" id="Vector_2" />
        </g>
        <defs>
          <clipPath id="clip0_1_2203">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame1984078656() {
  return (
    <div className="content-stretch flex gap-[40px] items-center justify-start relative shrink-0">
      <Frame1984078658 />
      <Frame1984078649 />
      <RulesBox5 />
      <RulesBox6 />
      <RulesBox7 />
      <RulesBox8 />
      <ContentCopy />
    </div>
  );
}

function Frame1984078655() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[10px] items-center justify-start px-[10px] py-0 relative w-full">
          <Frame1984078656 />
        </div>
      </div>
    </div>
  );
}

function SearchIcon() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Search icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Search icon">
          <path d={svgPaths.p272bfa00} id="Icon" stroke="var(--stroke-0, #121215)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.3" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Left() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-start relative shrink-0" data-name="Left">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(18,18,21,0.3)] text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[1.2] whitespace-pre">Search Rules</p>
      </div>
    </div>
  );
}

function Search() {
  return (
    <div className="bg-white relative rounded-[24px] shrink-0 w-full" data-name="Search">
      <div aria-hidden="true" className="absolute border border-[rgba(18,18,21,0.3)] border-solid inset-0 pointer-events-none rounded-[24px]" />
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[14px] items-center justify-start px-[16px] py-[8px] relative w-full">
          <SearchIcon />
          <Left />
        </div>
      </div>
    </div>
  );
}

function ArrowDown3() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078571() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">General</p>
      </div>
    </div>
  );
}

function Frame1984078572() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-start p-[8px] relative w-full">
          <ArrowDown3 />
          <Frame1984078571 />
        </div>
      </div>
    </div>
  );
}

function ArrowDown4() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078573() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Rules</p>
      </div>
    </div>
  );
}

function Frame1984078560() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-start p-[8px] relative w-full">
          <ArrowDown4 />
          <Frame1984078573 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078634() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start relative shrink-0 w-[273px]">
      <Frame1984078572 />
      <Frame1984078560 />
    </div>
  );
}

function ArrowDown5() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078574() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Workflows</p>
      </div>
    </div>
  );
}

function Frame1984078575() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-start p-[8px] relative w-full">
          <ArrowDown5 />
          <Frame1984078574 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078633() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start relative shrink-0 w-[273px]">
      <Frame1984078575 />
    </div>
  );
}

function ArrowDown6() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078576() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">AI Prompt Rules</p>
      </div>
    </div>
  );
}

function Frame1984078577() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-start p-[8px] relative w-full">
          <ArrowDown6 />
          <Frame1984078576 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078563() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start relative shrink-0 w-[273px]">
      <Frame1984078577 />
    </div>
  );
}

function ArrowDown7() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078578() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Deterministic Rules</p>
      </div>
    </div>
  );
}

function Frame1984078579() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-start p-[8px] relative w-full">
          <ArrowDown7 />
          <Frame1984078578 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078630() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start relative shrink-0 w-[273px]">
      <Frame1984078579 />
    </div>
  );
}

function ArrowDown8() {
  return (
    <div className="h-[5px] relative w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078580() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Top 10 Rules</p>
      </div>
    </div>
  );
}

function Frame1984078581() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-start p-[8px] relative w-full">
          <div className="flex h-[9px] items-center justify-center relative shrink-0 w-[5px]">
            <div className="flex-none rotate-[90deg] scale-y-[-100%]">
              <ArrowDown8 />
            </div>
          </div>
          <Frame1984078580 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078635() {
  return (
    <div className="bg-[#eaf2f7] content-stretch flex flex-col gap-[8px] items-start justify-start relative shrink-0 w-full">
      <Frame1984078581 />
    </div>
  );
}

function InfoIcon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="INFO icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_2227)" id="INFO icon">
          <g id="Vector"></g>
          <path d={svgPaths.p1d402c00} id="Vector_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 9H12.01" id="Vector_3" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M11 12H12V16H13" id="Vector_4" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_1_2227">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame1984078582() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Rule name</p>
      </div>
    </div>
  );
}

function Frame1984078659() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-start relative shrink-0">
      <InfoIcon />
      <Frame1984078582 />
    </div>
  );
}

function Close() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="close">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="close">
          <path d={svgPaths.p6140b00} fill="var(--fill-0, #B3261E)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Frame1984078583() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between p-[8px] relative w-full">
          <Frame1984078659 />
          <Close />
        </div>
      </div>
    </div>
  );
}

function RulesBox9() {
  return (
    <div className="bg-white relative shrink-0 w-full" data-name="Rules box">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[10px] relative w-full">
          <Frame1984078583 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078637() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[10px] items-start justify-start px-[10px] py-0 relative w-full">
          <RulesBox9 />
        </div>
      </div>
    </div>
  );
}

function Scrollbar() {
  return (
    <div className="bg-[#e4e4e5] h-[686px] overflow-clip relative w-[15px]" data-name="Scrollbar">
      <div className="absolute bg-[#e4e4e5] bottom-[7px] right-[8px] rounded-[100px] top-0 w-[4px]" data-name="Scrollbar" />
      <div className="absolute bottom-0 flex items-center justify-center right-[8px] top-[161px] w-[4px]">
        <div className="flex-none h-[525px] scale-y-[-100%] w-[4px]">
          <div className="bg-[#79747e] rounded-[100px] size-full" data-name="Scrollbar" />
        </div>
      </div>
    </div>
  );
}

function Frame1984078636() {
  return (
    <div className="basis-0 bg-[#e4e4e5] box-border content-stretch flex flex-col gap-[18px] grow items-start justify-start min-h-px min-w-px pb-[10px] pt-0 px-0 relative shrink-0 w-[273px]">
      <div aria-hidden="true" className="absolute border border-[#e4e4e5] border-solid inset-0 pointer-events-none" />
      <Frame1984078635 />
      {[...Array(9).keys()].map((_, i) => (
        <Frame1984078637 key={i} />
      ))}
      <div className="absolute flex h-[686px] items-center justify-center left-[257px] top-[51px] w-[15px]">
        <div className="flex-none rotate-[180deg]">
          <Scrollbar />
        </div>
      </div>
    </div>
  );
}

function RightSides() {
  return (
    <div className="bg-[rgba(228,228,229,0.2)] box-border content-stretch flex flex-col gap-[16px] h-full items-start justify-start px-[8px] py-[16px] relative shrink-0" data-name="Right sides">
      <div aria-hidden="true" className="absolute border border-[#e4e4e5] border-solid inset-0 pointer-events-none" />
      <Search />
      <Frame1984078634 />
      <Frame1984078633 />
      <Frame1984078563 />
      <Frame1984078630 />
      <Frame1984078636 />
    </div>
  );
}

function Frame1984078631() {
  return (
    <div className="absolute bg-[#2476b7] box-border content-stretch flex gap-[10px] h-[93px] items-center justify-center left-[596px] px-[79px] py-[37px] top-[803px] w-[193px]">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-nowrap text-white" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">End</p>
      </div>
    </div>
  );
}

function Path() {
  return (
    <div className="h-[142px] relative w-[88px]" data-name="Path">
      <div className="absolute inset-[-1.06%_-1.7%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 92 146">
          <g id="Path">
            <path d={svgPaths.pfddec00} id="Path_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Path1() {
  return (
    <div className="h-[8px] relative w-[88px]" data-name="Path">
      <div className="absolute bottom-0 left-[-1.7%] right-[-1.7%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 92 8">
          <g id="Path">
            <path d="M2 4.00001L90 4.00001" id="Path_2" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeWidth="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078600() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Rule name 1</p>
      </div>
    </div>
  );
}

function ArrowDown9() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 5">
        <g id="Arrow down"></g>
      </svg>
    </div>
  );
}

function Close9() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="close">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="close">
          <path d={svgPaths.p6140b00} fill="var(--fill-0, #B3261E)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Frame1984078601() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between pl-[16px] pr-[8px] py-[8px] relative w-full">
          <Frame1984078600 />
          <ArrowDown9 />
          <Close9 />
        </div>
      </div>
    </div>
  );
}

function RulesBox18() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div aria-hidden="true" className="absolute border border-[rgba(18,18,21,0.3)] border-solid inset-0 pointer-events-none" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[10px] relative w-full">
          <Frame1984078601 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078602() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Rule name 2</p>
      </div>
    </div>
  );
}

function ArrowDown10() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 5">
        <g id="Arrow down"></g>
      </svg>
    </div>
  );
}

function Close10() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="close">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="close">
          <path d={svgPaths.p6140b00} fill="var(--fill-0, #B3261E)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Frame1984078603() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between pl-[16px] pr-[8px] py-[8px] relative w-full">
          <Frame1984078602 />
          <ArrowDown10 />
          <Close10 />
        </div>
      </div>
    </div>
  );
}

function RulesBox19() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div aria-hidden="true" className="absolute border border-[rgba(18,18,21,0.3)] border-solid inset-0 pointer-events-none" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[10px] relative w-full">
          <Frame1984078603 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078638() {
  return (
    <div className="content-stretch flex gap-[16px] items-center justify-start relative shrink-0 w-[335px]">
      <RulesBox18 />
      <RulesBox19 />
    </div>
  );
}

function RuleIndividual() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-[16px] items-start justify-center left-[63px] p-[16px] top-[261px] w-[796px]" data-name="Rule  individual">
      <Frame1984078638 />
    </div>
  );
}

function Frame1984078604() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Rule name 3</p>
      </div>
    </div>
  );
}

function ArrowDown11() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 5">
        <g id="Arrow down"></g>
      </svg>
    </div>
  );
}

function Close11() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="close">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="close">
          <path d={svgPaths.p6140b00} fill="var(--fill-0, #B3261E)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function Frame1984078605() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between pl-[16px] pr-[8px] py-[8px] relative w-full">
          <Frame1984078604 />
          <ArrowDown11 />
          <Close11 />
        </div>
      </div>
    </div>
  );
}

function RulesBox20() {
  return (
    <div className="basis-0 bg-white grow min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div aria-hidden="true" className="absolute border-2 border-[#0f4977] border-solid inset-0 pointer-events-none" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[10px] relative w-full">
          <Frame1984078605 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078639() {
  return (
    <div className="content-stretch flex gap-[16px] items-center justify-start relative shrink-0 w-[335px]">
      <RulesBox20 />
    </div>
  );
}

function RuleIndividual1() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-[16px] items-start justify-center left-[63px] p-[16px] top-[360px] w-[796px]" data-name="Rule  individual">
      <Frame1984078639 />
    </div>
  );
}

function Frame1984078632() {
  return (
    <div className="absolute bg-[#ffaaaa] box-border content-stretch flex gap-[10px] items-center justify-center left-[221px] px-[10px] py-[6px] rounded-[16px] top-[223px]">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[12px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Sequence</p>
      </div>
    </div>
  );
}

function Frame1984078626() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-full">
      <div className="absolute bg-white h-[1069px] left-0 top-0 w-[1192px]" />
      <div className="absolute bg-[0%_25.12%] bg-no-repeat bg-size-[100%_173.36%] h-[1084px] left-0 top-0 w-[895px]" data-name="image 15" style={{ backgroundImage: `url('${imgImage15}')` }} />
      <div className="absolute bg-[rgba(179,38,30,0.5)] h-[93px] left-[63px] top-[111px] w-[193px]" />
      <Frame1984078631 />
      <div className="absolute flex h-[88px] items-center justify-center left-[157px] top-[198px] w-[142px]">
        <div className="flex-none rotate-[90deg] scale-y-[-100%]">
          <Path />
        </div>
      </div>
      <div className="absolute flex h-[88px] items-center justify-center left-[152px] top-[198px] w-[8px]">
        <div className="flex-none rotate-[90deg] scale-y-[-100%]">
          {[...Array(2).keys()].map((_, i) => (
            <Path1 key={i} />
          ))}
        </div>
      </div>
      <div className="absolute flex h-[88px] items-center justify-center left-[152px] top-[302px] w-[8px]">
        <div className="flex-none rotate-[90deg] scale-y-[-100%]" />
      </div>
      <div className="absolute bg-[#47a14b] h-[93px] left-[63px] top-[111px] w-[193px]" />
      <div className="absolute font-['Roboto:Regular',_sans-serif] font-normal leading-[0] left-[134px] text-[16px] text-nowrap text-white top-[204px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Start</p>
      </div>
      <div className="absolute font-['Roboto:Regular',_sans-serif] font-normal leading-[0] left-[141px] text-[16px] text-nowrap text-white top-[147px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Start</p>
      </div>
      <RuleIndividual />
      <RuleIndividual1 />
      <Frame1984078632 />
    </div>
  );
}

function Frame1984078627() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[1069px] items-start justify-start relative shrink-0 w-full">
      <Frame1984078626 />
    </div>
  );
}

function Frame1984078619() {
  return (
    <div className="basis-0 content-stretch flex flex-col grow h-full items-center justify-between min-h-px min-w-px relative shrink-0">
      <Frame1984078627 />
    </div>
  );
}

function Frame1984078606() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#0f4977] text-[16px] text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Style</p>
      </div>
    </div>
  );
}

function Frame1984078607() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-full">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-center pl-[16px] pr-[8px] py-[8px] relative size-full">
          <Frame1984078606 />
        </div>
      </div>
    </div>
  );
}

function RulesBox21() {
  return (
    <div className="basis-0 bg-white grow h-full min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div aria-hidden="true" className="absolute border-[#0f4977] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[10px] relative size-full">
          <Frame1984078607 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078608() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Text</p>
      </div>
    </div>
  );
}

function ArrowDown12() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9 5">
        <g id="Arrow down"></g>
      </svg>
    </div>
  );
}

function Frame1984078609() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-full">
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex gap-[6px] items-center justify-center pl-[16px] pr-[8px] py-[8px] relative size-full">
          <Frame1984078608 />
          <ArrowDown12 />
        </div>
      </div>
    </div>
  );
}

function RulesBox22() {
  return (
    <div className="basis-0 bg-[rgba(228,228,229,0.2)] grow h-full min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[10px] relative size-full">
          <Frame1984078609 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078610() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Advance</p>
      </div>
    </div>
  );
}

function Frame1984078611() {
  return (
    <div className="basis-0 box-border content-stretch flex gap-[6px] grow items-center justify-center min-h-px min-w-px px-0 py-[8px] relative shrink-0">
      <Frame1984078610 />
    </div>
  );
}

function RulesBox23() {
  return (
    <div className="basis-0 bg-[rgba(228,228,229,0.2)] grow h-full min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-[8px] items-start justify-start p-[10px] relative size-full">
          <Frame1984078611 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078657() {
  return (
    <div className="content-stretch flex h-[45px] items-start justify-start relative shrink-0 w-full">
      <RulesBox21 />
      <RulesBox22 />
      <RulesBox23 />
    </div>
  );
}

function ArrowDown13() {
  return (
    <div className="h-[5px] relative w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078668() {
  return (
    <div className="box-border content-stretch flex gap-[10px] items-center justify-start p-[10px] relative shrink-0">
      <div className="flex h-[9px] items-center justify-center relative shrink-0 w-[5px]">
        <div className="flex-none rotate-[90deg]">
          <ArrowDown13 />
        </div>
      </div>
    </div>
  );
}

function RulesBox24() {
  return <div className="bg-white h-[35.502px] shrink-0 w-[52.266px]" data-name="Rules box" />;
}

function RulesBox25() {
  return <div className="bg-[#ffe3e3] h-[35.502px] shrink-0 w-[52.266px]" data-name="Rules box" />;
}

function RulesBox26() {
  return <div className="bg-[#f3faff] h-[35.502px] shrink-0 w-[52.266px]" data-name="Rules box" />;
}

function RulesBox27() {
  return <div className="bg-[#fcffcf] h-[35.502px] shrink-0 w-[52.266px]" data-name="Rules box" />;
}

function Frame1984078669() {
  return (
    <div className="content-stretch flex gap-[6.311px] items-center justify-start relative shrink-0">
      <RulesBox24 />
      <RulesBox25 />
      <RulesBox26 />
      <RulesBox27 />
    </div>
  );
}

function RulesBox28() {
  return (
    <div className="basis-0 bg-[#dbffce] grow h-full min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div className="relative size-full">
        <div className="size-full" />
      </div>
    </div>
  );
}

function RulesBox29() {
  return (
    <div className="basis-0 bg-[#c5fffc] grow h-full min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div className="relative size-full">
        <div className="size-full" />
      </div>
    </div>
  );
}

function RulesBox30() {
  return (
    <div className="basis-0 bg-black grow h-full min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div className="relative size-full">
        <div className="size-full" />
      </div>
    </div>
  );
}

function RulesBox31() {
  return (
    <div className="basis-0 bg-[#ffc0fe] grow h-full min-h-px min-w-px relative shrink-0" data-name="Rules box">
      <div className="relative size-full">
        <div className="size-full" />
      </div>
    </div>
  );
}

function Frame1984078670() {
  return (
    <div className="content-stretch flex gap-[8px] h-[43px] items-center justify-start relative shrink-0 w-full">
      <RulesBox28 />
      <RulesBox29 />
      <RulesBox30 />
      <RulesBox31 />
    </div>
  );
}

function Colors() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start relative shrink-0" data-name="Colors">
      <Frame1984078669 />
      <Frame1984078670 />
    </div>
  );
}

function ArrowDown14() {
  return (
    <div className="h-[5px] relative w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078671() {
  return (
    <div className="box-border content-stretch flex gap-[10px] items-center justify-start p-[10px] relative">
      <div className="flex h-[9px] items-center justify-center relative shrink-0 w-[5px]">
        <div className="flex-none rotate-[90deg]">
          <ArrowDown14 />
        </div>
      </div>
    </div>
  );
}

function Color() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0 w-full" data-name="Color">
      <Frame1984078668 />
      <Colors />
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <Frame1984078671 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078672() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start relative shrink-0 w-full">
      <Frame1984078657 />
      <Color />
    </div>
  );
}

function StateLayer() {
  return (
    <div className="content-stretch flex items-center justify-center relative rounded-[100px] shrink-0" data-name="state-layer">
      <div className="relative rounded-[2px] shrink-0 size-[18px]" data-name="container">
        <div aria-hidden="true" className="absolute border-2 border-[#49454f] border-solid inset-0 pointer-events-none rounded-[2px]" />
      </div>
    </div>
  );
}

function Checkboxes() {
  return (
    <div className="box-border content-stretch flex flex-col items-center justify-center p-[4px] relative shrink-0" data-name="Checkboxes">
      <StateLayer />
    </div>
  );
}

function Frame1984078612() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Fill</p>
      </div>
    </div>
  );
}

function Frame1984078561() {
  return (
    <div className="box-border content-stretch flex gap-[6px] items-center justify-start px-0 py-[8px] relative shrink-0">
      <Checkboxes />
      <Frame1984078612 />
    </div>
  );
}

function Frame1984078613() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Auto</p>
      </div>
    </div>
  );
}

function ArrowDown15() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078614() {
  return (
    <div className="bg-[#e4e4e5] box-border content-stretch flex gap-[6px] items-center justify-start p-[8px] relative shrink-0">
      <Frame1984078613 />
      <ArrowDown15 />
    </div>
  );
}

function RulesBox32() {
  return <div className="bg-white h-[26px] shrink-0 w-[39px]" data-name="Rules box" />;
}

function Frame1984078673() {
  return (
    <div className="bg-[#eaf2f7] box-border content-stretch flex gap-[10px] items-start justify-start p-[4px] relative shrink-0">
      <RulesBox32 />
      <div className="bg-center bg-contain bg-no-repeat shrink-0 size-[24px]" data-name="Color Dropper" style={{ backgroundImage: `url('${imgColorDropper}')` }} />
    </div>
  );
}

function Fill() {
  return (
    <div className="relative shrink-0 w-full" data-name="Fill">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[10px] py-0 relative w-full">
          <Frame1984078561 />
          <Frame1984078614 />
          <Frame1984078673 />
        </div>
      </div>
    </div>
  );
}

function StateLayer1() {
  return (
    <div className="content-stretch flex items-center justify-center relative rounded-[100px] shrink-0" data-name="state-layer">
      <div className="relative rounded-[2px] shrink-0 size-[18px]" data-name="container">
        <div aria-hidden="true" className="absolute border-2 border-[#49454f] border-solid inset-0 pointer-events-none rounded-[2px]" />
      </div>
    </div>
  );
}

function Checkboxes1() {
  return (
    <div className="box-border content-stretch flex flex-col items-center justify-center p-[4px] relative shrink-0" data-name="Checkboxes">
      <StateLayer1 />
    </div>
  );
}

function Frame1984078615() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Gradient</p>
      </div>
    </div>
  );
}

function Frame1984078616() {
  return (
    <div className="box-border content-stretch flex gap-[6px] items-center justify-start px-0 py-[8px] relative shrink-0">
      <Checkboxes1 />
      <Frame1984078615 />
    </div>
  );
}

function Fill1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Fill">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-start px-[10px] py-0 relative w-full">
          <Frame1984078616 />
        </div>
      </div>
    </div>
  );
}

function StateLayer2() {
  return (
    <div className="content-stretch flex items-center justify-center relative rounded-[100px] shrink-0" data-name="state-layer">
      <div className="relative rounded-[2px] shrink-0 size-[18px]" data-name="container">
        <div aria-hidden="true" className="absolute border-2 border-[#49454f] border-solid inset-0 pointer-events-none rounded-[2px]" />
      </div>
    </div>
  );
}

function Checkboxes2() {
  return (
    <div className="box-border content-stretch flex flex-col items-center justify-center p-[4px] relative shrink-0" data-name="Checkboxes">
      <StateLayer2 />
    </div>
  );
}

function Frame1984078617() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Line</p>
      </div>
    </div>
  );
}

function Frame1984078618() {
  return (
    <div className="box-border content-stretch flex gap-[6px] items-center justify-start px-0 py-[8px] relative shrink-0">
      <Checkboxes2 />
      <Frame1984078617 />
    </div>
  );
}

function RulesBox33() {
  return <div className="bg-black h-[26px] shrink-0 w-[39px]" data-name="Rules box" />;
}

function Frame1984078674() {
  return (
    <div className="bg-[#eaf2f7] box-border content-stretch flex gap-[10px] items-start justify-start p-[4px] relative shrink-0">
      <RulesBox33 />
      <div className="bg-center bg-contain bg-no-repeat shrink-0 size-[24px]" data-name="Color Dropper" style={{ backgroundImage: `url('${imgColorDropper}')` }} />
    </div>
  );
}

function Fill2() {
  return (
    <div className="relative shrink-0 w-full" data-name="Fill">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex items-center justify-between px-[10px] py-0 relative w-full">
          <Frame1984078618 />
          <Frame1984078674 />
        </div>
      </div>
    </div>
  );
}

function Frame1984078621() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-start relative shrink-0">
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[16px] text-black text-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal] whitespace-pre">Perimeter</p>
      </div>
    </div>
  );
}

function Frame1984078624() {
  return (
    <div className="box-border content-stretch flex gap-[6px] items-center justify-start px-0 py-[8px] relative shrink-0">
      <Frame1984078621 />
    </div>
  );
}

function Fill3() {
  return (
    <div className="relative shrink-0 w-full" data-name="Fill">
      <div className="flex flex-row items-center relative size-full">
        <div className="box-border content-stretch flex gap-[8px] items-center justify-start px-[10px] py-0 relative w-full">
          <Frame1984078624 />
        </div>
      </div>
    </div>
  );
}

function ArrowDown16() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078625() {
  return (
    <div className="bg-[#e4e4e5] box-border content-stretch flex gap-[6px] h-full items-center justify-start p-[8px] relative shrink-0">
      <div className="h-0 relative shrink-0 w-[175px]">
        <div className="absolute bottom-[-0.5px] left-0 right-0 top-[-0.5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 175 2">
            <path d="M0 1H175" id="Vector 7108" stroke="var(--stroke-0, black)" />
          </svg>
        </div>
      </div>
      <ArrowDown16 />
    </div>
  );
}

function ArrowDown17() {
  return (
    <div className="h-[5px] relative w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ArrowDown18() {
  return (
    <div className="h-[5px] relative shrink-0 w-[9px]" data-name="Arrow down">
      <div className="absolute inset-[-10%_-5.56%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 7">
          <g id="Arrow down">
            <path clipRule="evenodd" d={svgPaths.p29a69200} fill="var(--fill-0, black)" fillRule="evenodd" id="Arrow down_2" stroke="var(--stroke-0, black)" strokeLinecap="round" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame1984078675() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] items-start justify-center relative self-stretch shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none scale-y-[-100%]">
          <ArrowDown17 />
        </div>
      </div>
      <ArrowDown18 />
    </div>
  );
}

function Frame1984078676() {
  return (
    <div className="bg-white box-border content-stretch flex gap-[10px] items-start justify-start p-[4px] relative shrink-0">
      <div aria-hidden="true" className="absolute border border-[#e4e4e5] border-solid inset-0 pointer-events-none" />
      <div className="font-['Roboto:Regular',_sans-serif] font-normal leading-[0] relative self-stretch shrink-0 text-[16px] text-black w-[28px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[normal]">1 pt</p>
      </div>
      <Frame1984078675 />
    </div>
  );
}

function Frame1984078652() {
  return (
    <div className="content-stretch flex gap-[10px] items-center justify-center relative shrink-0 w-[296px]">
      <div className="flex flex-row items-center self-stretch">
        <Frame1984078625 />
      </div>
      <Frame1984078676 />
    </div>
  );
}

function Frame1984078650() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start justify-start relative shrink-0 w-full">
      <Fill />
      <Fill1 />
      <Fill2 />
      <Fill3 />
      <Frame1984078652 />
    </div>
  );
}

function Frame1984078677() {
  return (
    <div className="bg-neutral-50 box-border content-stretch flex flex-col gap-[15px] h-full items-start justify-start pb-[10px] pt-0 px-0 relative shrink-0 w-[296px]">
      <Frame1984078672 />
      <Frame1984078650 />
    </div>
  );
}

function Frame1984078620() {
  return (
    <div className="content-stretch flex h-[1069px] items-start justify-start relative shrink-0 w-full">
      <RightSides />
      <Frame1984078619 />
      <Frame1984078677 />
    </div>
  );
}

export default function Frame1984078653() {
  return (
    <div className="content-stretch flex flex-col items-start justify-start relative size-full">
      <Frame1984078277 />
      <Frame1984078654 />
      <Frame1984078655 />
      <Frame1984078620 />
    </div>
  );
}