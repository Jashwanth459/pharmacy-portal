export default function Rectangle39912() {
  return <div className="bg-[rgba(18,18,21,0.3)] size-full" />;
}