import React, { useState, useRef, useCallback } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Search, Filter, ChevronDown, ChevronRight, Info, X, Plus, ZoomIn, ZoomOut, Copy, Palette, ArrowDown, Save, FileText, Folder, Edit3, Eye, Settings, Bot, Undo, Redo, MousePointer2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Checkbox } from './ui/checkbox';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from './ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner@2.0.3';
import svgPaths from '../imports/svg-93yvdn64qj';

interface Rule {
  id: string;
  name: string;
  category: string;
}

interface WorkflowNode {
  id: string;
  type: 'start' | 'end' | 'rule';
  name?: string;
  x: number;
  y: number;
  width?: number;
  height?: number;
  backgroundColor?: string;
  borderColor?: string;
  textColor?: string;
}

interface NodeStyle {
  backgroundColor: string;
  borderColor: string;
  textColor: string;
  borderWidth: number;
  borderStyle: string;
}

interface Connection {
  id: string;
  from: string;
  to: string;
}

interface WorkflowData {
  id: string;
  name: string;
  description: string;
  nodes: any[];
  connections: any[];
  createdAt: Date;
  updatedAt: Date;
}

interface WorkflowEditorProps {
  onClose: () => void;
  currentWorkflow: WorkflowData | null;
  onWorkflowCreated: (name: string, description: string) => void;
  onWorkflowSaved: (workflowData: { nodes: WorkflowNode[]; connections: Connection[] }) => void;
}

const RULE_CATEGORIES = [
  { id: 'general', name: 'General', expanded: true },
  { id: 'rules', name: 'Rules', expanded: true },
  { id: 'workflows', name: 'Workflows', expanded: false },
  { id: 'ai-prompt-rules', name: 'AI Prompt Rules', expanded: false },
  { id: 'deterministic-rules', name: 'Deterministic Rules', expanded: false },
  { id: 'top-10-rules', name: 'Top 10 Rules', expanded: true, highlighted: true }
];

const SAMPLE_RULES: Rule[] = [
  { id: 'rule-1', name: 'Rule name', category: 'top-10-rules' },
  { id: 'rule-2', name: 'Rule name', category: 'top-10-rules' },
  { id: 'rule-3', name: 'Rule name', category: 'top-10-rules' },
  { id: 'rule-4', name: 'Rule name', category: 'top-10-rules' },
  { id: 'rule-5', name: 'Rule name', category: 'top-10-rules' },
  { id: 'rule-6', name: 'Rule name', category: 'top-10-rules' },
  { id: 'rule-7', name: 'Rule name', category: 'top-10-rules' },
  { id: 'rule-8', name: 'Rule name', category: 'top-10-rules' },
  { id: 'rule-9', name: 'Rule name', category: 'top-10-rules' },
];

const RuleItem: React.FC<{ rule: Rule }> = ({ rule }) => {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'rule',
    item: { id: rule.id, name: rule.name },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }), [rule.id, rule.name]);

  return (
    <div
      ref={drag}
      className={`bg-white border border-gray-200 rounded-lg p-2 mb-2 cursor-move transition-opacity hover:shadow-md ${
        isDragging ? 'opacity-50' : ''
      }`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-blue-500 rounded"></div>
          <span className="text-sm text-gray-800 font-medium">{rule.name}</span>
        </div>
        <X 
          className="w-4 h-4 text-gray-400 hover:text-red-500 cursor-pointer" 
          onClick={(e) => {
            e.stopPropagation();
            toast.info('Rule removed from list');
          }}
        />
      </div>
    </div>
  );
};

const WorkflowCanvas: React.FC<{
  nodes: WorkflowNode[];
  connections: Connection[];
  selectedNode: string | null;
  connectingNode: string | null;
  onAddNode: (node: Omit<WorkflowNode, 'id'>) => void;
  onDeleteNode: (id: string) => void;
  onUpdateNode: (id: string, updates: Partial<WorkflowNode>) => void;
  onSelectNode: (id: string | null) => void;
  onStartConnection: (id: string) => void;
  onCompleteConnection: (fromId: string, toId: string) => void;
}> = ({ 
  nodes, 
  connections, 
  selectedNode, 
  connectingNode, 
  onAddNode, 
  onDeleteNode, 
  onUpdateNode, 
  onSelectNode, 
  onStartConnection, 
  onCompleteConnection 
}) => {
  const canvasRef = useRef<HTMLDivElement>(null);

  const [{ isOver }, drop] = useDrop(() => ({
    accept: 'rule',
    drop: (item: { id: string; name: string }, monitor) => {
      if (!canvasRef.current) return;
      
      const canvasRect = canvasRef.current.getBoundingClientRect();
      const clientOffset = monitor.getClientOffset();
      
      if (clientOffset) {
        const x = Math.max(0, clientOffset.x - canvasRect.left - 100);
        const y = Math.max(0, clientOffset.y - canvasRect.top - 30);
        
        onAddNode({
          type: 'rule',
          name: item.name,
          x,
          y,
          width: 200,
          height: 60,
          backgroundColor: '#ffffff',
          borderColor: '#2563eb',
          textColor: '#000000'
        });
      }
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }));

  const handleNodeClick = (nodeId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    
    if (connectingNode && connectingNode !== nodeId) {
      onCompleteConnection(connectingNode, nodeId);
      return;
    }
    
    onSelectNode(nodeId);
  };

  const handleNodeDoubleClick = (nodeId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    onStartConnection(nodeId);
  };

  const handleCanvasClick = () => {
    onSelectNode(null);
  };

  return (
    <div
      ref={(node) => {
        drop(node);
        if (node) canvasRef.current = node;
      }}
      className={`relative w-full h-full bg-white border-l border-gray-200 overflow-auto ${
        isOver ? 'bg-blue-50' : ''
      }`}
      style={{
        backgroundImage: `url("data:image/svg+xml,%3csvg width='100' height='100' xmlns='http://www.w3.org/2000/svg'%3e%3cdefs%3e%3cpattern id='grid' width='20' height='20' patternUnits='userSpaceOnUse'%3e%3cpath d='M 20 0 L 0 0 0 20' fill='none' stroke='%23f0f0f0' stroke-width='1'/%3e%3c/pattern%3e%3c/defs%3e%3crect width='100%25' height='100%25' fill='url(%23grid)' /%3e%3c/svg%3e")`,
        minHeight: '1000px',
        minWidth: '1200px',
      }}
      onClick={handleCanvasClick}
    >
      {/* Connection instruction */}
      {connectingNode && (
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white px-4 py-2 rounded-lg shadow-lg z-50">
          Click on another node to connect
        </div>
      )}

      {/* Render connections */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ minHeight: '1000px', minWidth: '1200px' }}>
        {connections.map((connection) => {
          const fromNode = nodes.find((n) => n.id === connection.from);
          const toNode = nodes.find((n) => n.id === connection.to);
          
          if (!fromNode || !toNode) return null;
          
          const x1 = fromNode.x + (fromNode.width || 193) / 2;
          const y1 = fromNode.y + (fromNode.height || 93);
          const x2 = toNode.x + (toNode.width || 193) / 2;
          const y2 = toNode.y;
          
          const midY = y1 + (y2 - y1) / 2;
          
          return (
            <g key={connection.id}>
              <path
                d={`M ${x1} ${y1} C ${x1} ${midY} ${x2} ${midY} ${x2} ${y2}`}
                stroke="#2563eb"
                strokeWidth="2"
                fill="none"
                strokeLinecap="round"
              />
              {/* Arrow head */}
              <path
                d={`M ${x2-8} ${y2-8} L ${x2} ${y2} L ${x2-8} ${y2+8}`}
                stroke="#2563eb"
                strokeWidth="2"
                fill="none"
                strokeLinecap="round"
              />
            </g>
          );
        })}
      </svg>

      {/* Render nodes */}
      {nodes.map((node) => (
        <div
          key={node.id}
          className={`absolute rounded-lg shadow-lg flex items-center justify-center cursor-pointer transition-all duration-200 ${
            selectedNode === node.id ? 'ring-2 ring-blue-400' : ''
          } ${connectingNode === node.id ? 'ring-2 ring-green-400' : ''}`}
          style={{
            left: node.x,
            top: node.y,
            width: node.width || 193,
            height: node.height || 93,
            backgroundColor: node.type === 'start' 
              ? '#10b981' 
              : node.type === 'end' 
              ? '#2563eb' 
              : node.backgroundColor || '#ffffff',
            border: node.type === 'rule' ? `2px solid ${node.borderColor || '#2563eb'}` : 'none',
            color: node.type === 'start' || node.type === 'end' 
              ? '#ffffff' 
              : node.textColor || '#000000',
            zIndex: selectedNode === node.id ? 10 : 1
          }}
          onClick={(e) => handleNodeClick(node.id, e)}
          onDoubleClick={(e) => handleNodeDoubleClick(node.id, e)}
        >
          {node.type === 'rule' && (
            <div className="absolute top-1 right-1">
              <X
                className="w-4 h-4 text-red-500 cursor-pointer hover:text-red-700"
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteNode(node.id);
                }}
              />
            </div>
          )}
          <span className="text-center px-2 select-none text-sm font-medium">
            {node.type === 'start' ? 'Start' : node.type === 'end' ? 'End' : node.name}
          </span>
          {node.type === 'rule' && connections.some(c => c.from === node.id || c.to === node.id) && (
            <div className="absolute -top-7 left-1/2 transform -translate-x-1/2">
              <div className="bg-red-100 text-red-700 px-2 py-1 rounded text-xs font-medium">
                Sequence
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

const LeftSidebar: React.FC<{
  categories: typeof RULE_CATEGORIES;
  rules: Rule[];
  onToggleCategory: (categoryId: string) => void;
}> = ({ categories, rules, onToggleCategory }) => {
  return (
    <div className="w-72 bg-gray-100 border-r border-gray-300 flex flex-col h-full">
      {/* Search */}
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Search Rules"
            className="pl-10 rounded-full border-gray-400"
          />
        </div>
      </div>

      {/* Categories */}
      <div className="flex-1 overflow-y-auto">
        {categories.map((category) => (
          <div key={category.id} className="mb-2">
            <button
              onClick={() => onToggleCategory(category.id)}
              className={`w-full flex items-center gap-2 p-3 text-left hover:bg-gray-200 transition-colors ${
                category.highlighted ? 'bg-blue-100' : ''
              }`}
            >
              {category.expanded ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
              <span className="font-medium">{category.name}</span>
            </button>

            {category.expanded && (
              <div className="px-4 pb-2">
                {rules
                  .filter((rule) => rule.category === category.id)
                  .map((rule) => (
                    <RuleItem key={rule.id} rule={rule} />
                  ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const TopControls: React.FC<{ 
  onNewWorkflow: () => void;
  onSaveWorkflow: () => void;
  zoom: number;
  onZoomChange: (zoom: number) => void;
  currentWorkflow: WorkflowData | null;
}> = ({ onNewWorkflow, onSaveWorkflow, zoom, onZoomChange, currentWorkflow }) => {
  const menuItems = {
    File: [
      { label: 'New Workflow', icon: <FileText className="w-4 h-4" />, action: onNewWorkflow },
      { label: 'Open...', icon: <Folder className="w-4 h-4" />, action: () => toast.info('Open workflow') },
      { 
        label: currentWorkflow ? `Save "${currentWorkflow.name}"` : 'Save', 
        icon: <Save className="w-4 h-4" />, 
        action: onSaveWorkflow,
        disabled: !currentWorkflow
      },
      { label: 'Save As...', icon: <Save className="w-4 h-4" />, action: () => toast.info('Save as...') },
      'separator',
      { label: 'Export', icon: <ArrowDown className="w-4 h-4" />, action: () => toast.info('Export workflow') },
    ],
    Edit: [
      { label: 'Undo', icon: <Undo className="w-4 h-4" />, action: () => toast.info('Undo') },
      { label: 'Redo', icon: <Redo className="w-4 h-4" />, action: () => toast.info('Redo') },
      'separator',
      { label: 'Cut', icon: <X className="w-4 h-4" />, action: () => toast.info('Cut') },
      { label: 'Copy', icon: <Copy className="w-4 h-4" />, action: () => toast.info('Copy') },
      { label: 'Paste', icon: <Plus className="w-4 h-4" />, action: () => toast.info('Paste') },
    ],
    View: [
      { label: 'Zoom In', icon: <ZoomIn className="w-4 h-4" />, action: () => onZoomChange(Math.min(zoom + 10, 200)) },
      { label: 'Zoom Out', icon: <ZoomOut className="w-4 h-4" />, action: () => onZoomChange(Math.max(zoom - 10, 10)) },
      { label: 'Fit to Screen', icon: <Eye className="w-4 h-4" />, action: () => onZoomChange(100) },
      'separator',
      { label: 'Grid', icon: <Settings className="w-4 h-4" />, action: () => toast.info('Toggle grid') },
    ],
    Extras: [
      { label: 'Preferences', icon: <Settings className="w-4 h-4" />, action: () => toast.info('Preferences') },
      { label: 'Tools', icon: <Edit3 className="w-4 h-4" />, action: () => toast.info('Tools') },
    ],
    AI: [
      { label: 'AI Assistant', icon: <Bot className="w-4 h-4" />, action: () => toast.info('AI Assistant') },
      { label: 'Generate Rules', icon: <Plus className="w-4 h-4" />, action: () => toast.info('Generate rules') },
    ]
  };

  return (
    <div className="border-b border-gray-300">
      {/* Menu Bar */}
      <div className="flex bg-gray-100 border-b border-gray-300">
        {Object.entries(menuItems).map(([menuName, items]) => (
          <DropdownMenu key={menuName}>
            <DropdownMenuTrigger asChild>
              <button className="px-4 py-2 text-sm hover:bg-gray-200 transition-colors border-r border-gray-300">
                {menuName}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48">
              {items.map((item, index) => 
                item === 'separator' ? (
                  <DropdownMenuSeparator key={index} />
                ) : (
                  <DropdownMenuItem 
                    key={index} 
                    onClick={item.disabled ? undefined : item.action}
                    className={`flex items-center gap-2 ${
                      item.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
                    }`}
                    disabled={item.disabled}
                  >
                    {item.icon}
                    {item.label}
                  </DropdownMenuItem>
                )
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex items-center justify-between p-2 bg-gray-100">
        <div className="flex items-center gap-4">
          <button 
            className="p-2 hover:bg-gray-200 rounded transition-colors"
            onClick={() => onZoomChange(Math.max(zoom - 10, 10))}
          >
            <ZoomOut className="w-5 h-5" />
          </button>
          <button 
            className="p-2 hover:bg-gray-200 rounded transition-colors"
            onClick={() => onZoomChange(Math.min(zoom + 10, 200))}
          >
            <ZoomIn className="w-5 h-5" />
          </button>
          <div className="bg-white border border-gray-300 px-3 py-1 text-sm min-w-[80px] text-center rounded">
            {zoom}%
          </div>
          {currentWorkflow && (
            <div className="bg-blue-50 border border-blue-200 px-3 py-1 text-sm rounded text-blue-800">
              Editing: {currentWorkflow.name}
            </div>
          )}
          <button 
            className="p-2 hover:bg-gray-200 rounded transition-colors"
            onClick={() => toast.info('Color palette opened')}
          >
            <Palette className="w-5 h-5" />
          </button>
          <button 
            className="p-2 hover:bg-gray-200 rounded transition-colors"
            onClick={() => toast.info('Copied to clipboard')}
          >
            <Copy className="w-5 h-5" />
          </button>
          <button 
            className="p-2 hover:bg-gray-200 rounded transition-colors"
            onClick={() => toast.info('Selection tool active')}
          >
            <MousePointer2 className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

const ColorPicker: React.FC<{
  color: string;
  onChange: (color: string) => void;
  label: string;
}> = ({ color, onChange, label }) => {
  const colors = ['#ffffff', '#ffe3e3', '#f3faff', '#fcffcf', '#dbffce', '#c5fffc', '#000000', '#ffc0fe'];
  
  return (
    <div className="space-y-2">
      <label className="text-sm font-medium">{label}</label>
      <div className="flex items-center gap-2">
        <div 
          className="w-8 h-6 border border-gray-300 rounded cursor-pointer"
          style={{ backgroundColor: color }}
          onClick={() => {
            const newColor = prompt('Enter color (hex):', color);
            if (newColor) onChange(newColor);
          }}
        />
        <Input 
          type="text" 
          value={color} 
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 text-xs"
          placeholder="#000000"
        />
      </div>
      <div className="grid grid-cols-4 gap-1">
        {colors.map((presetColor) => (
          <div
            key={presetColor}
            className="w-8 h-6 rounded border border-gray-300 cursor-pointer hover:scale-110 transition-transform"
            style={{ backgroundColor: presetColor }}
            onClick={() => onChange(presetColor)}
          />
        ))}
      </div>
    </div>
  );
};

const RightPanel: React.FC<{
  selectedNode: string | null;
  nodes: WorkflowNode[];
  onUpdateNode: (id: string, updates: Partial<WorkflowNode>) => void;
}> = ({ selectedNode, nodes, onUpdateNode }) => {
  const [activeTab, setActiveTab] = useState('style');
  const [fillEnabled, setFillEnabled] = useState(true);
  const [lineEnabled, setLineEnabled] = useState(true);
  const [gradientEnabled, setGradientEnabled] = useState(false);
  const [borderWidth, setBorderWidth] = useState(1);

  const selectedNodeData = selectedNode ? nodes.find(n => n.id === selectedNode) : null;

  const handleStyleUpdate = (property: string, value: any) => {
    if (selectedNode && selectedNodeData) {
      onUpdateNode(selectedNode, { [property]: value });
    }
  };

  return (
    <div className="w-80 bg-gray-50 border-l border-gray-300 flex flex-col">
      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 bg-gray-100 border-b border-gray-300 rounded-none">
          <TabsTrigger value="style" className="text-sm data-[state=active]:bg-white">Style</TabsTrigger>
          <TabsTrigger value="text" className="text-sm data-[state=active]:bg-white">Text</TabsTrigger>
          <TabsTrigger value="advance" className="text-sm data-[state=active]:bg-white">Advance</TabsTrigger>
        </TabsList>

        <TabsContent value="style" className="flex-1 p-4 space-y-6">
          {selectedNodeData ? (
            <>
              {/* Colors Section */}
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <ChevronDown className="w-4 h-4" />
                  <span className="text-sm font-medium">Colors</span>
                </div>
                
                <div className="space-y-4">
                  <ColorPicker
                    color={selectedNodeData.backgroundColor || '#ffffff'}
                    onChange={(color) => handleStyleUpdate('backgroundColor', color)}
                    label="Background"
                  />
                  
                  <ColorPicker
                    color={selectedNodeData.textColor || '#000000'}
                    onChange={(color) => handleStyleUpdate('textColor', color)}
                    label="Text Color"
                  />
                  
                  <ColorPicker
                    color={selectedNodeData.borderColor || '#2563eb'}
                    onChange={(color) => handleStyleUpdate('borderColor', color)}
                    label="Border Color"
                  />
                </div>
              </div>

              {/* Fill Options */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Checkbox 
                      id="fill" 
                      checked={fillEnabled}
                      onCheckedChange={setFillEnabled}
                    />
                    <label htmlFor="fill" className="text-sm font-medium">Fill</label>
                  </div>
                  <select className="bg-white border border-gray-300 px-2 py-1 text-sm rounded">
                    <option>Solid</option>
                    <option>Linear</option>
                    <option>Radial</option>
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="gradient" 
                    checked={gradientEnabled}
                    onCheckedChange={setGradientEnabled}
                  />
                  <label htmlFor="gradient" className="text-sm font-medium">Gradient</label>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Checkbox 
                      id="line" 
                      checked={lineEnabled}
                      onCheckedChange={setLineEnabled}
                    />
                    <label htmlFor="line" className="text-sm font-medium">Border</label>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Border Width</label>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      value={borderWidth}
                      onChange={(e) => setBorderWidth(Number(e.target.value))}
                      className="w-20 text-sm"
                      min="0"
                      max="10"
                    />
                    <span className="text-sm text-gray-500">px</span>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center text-gray-500 mt-8">
              <Info className="w-8 h-8 mx-auto mb-2" />
              <p className="text-sm">Select a node to edit its style</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="text" className="flex-1 p-4 space-y-6">
          {selectedNodeData ? (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Node Name</label>
                <Input
                  value={selectedNodeData.name || ''}
                  onChange={(e) => handleStyleUpdate('name', e.target.value)}
                  placeholder="Enter node name"
                  className="w-full"
                />
              </div>
              
              <div>
                <label className="text-sm font-medium mb-2 block">Font Size</label>
                <select className="w-full bg-white border border-gray-300 px-3 py-2 text-sm rounded">
                  <option>12px</option>
                  <option>14px</option>
                  <option>16px</option>
                  <option>18px</option>
                  <option>20px</option>
                </select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Font Weight</label>
                <select className="w-full bg-white border border-gray-300 px-3 py-2 text-sm rounded">
                  <option>Normal</option>
                  <option>Medium</option>
                  <option>Bold</option>
                </select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Text Align</label>
                <div className="flex gap-2">
                  <button className="flex-1 px-3 py-2 bg-white border border-gray-300 text-sm rounded hover:bg-gray-50">
                    Left
                  </button>
                  <button className="flex-1 px-3 py-2 bg-blue-100 border border-blue-300 text-sm rounded">
                    Center
                  </button>
                  <button className="flex-1 px-3 py-2 bg-white border border-gray-300 text-sm rounded hover:bg-gray-50">
                    Right
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-500 mt-8">
              <Info className="w-8 h-8 mx-auto mb-2" />
              <p className="text-sm">Select a node to edit its text</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="advance" className="flex-1 p-4 space-y-6">
          {selectedNodeData ? (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Position</label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs text-gray-500">X</label>
                    <Input
                      type="number"
                      value={selectedNodeData.x}
                      onChange={(e) => handleStyleUpdate('x', Number(e.target.value))}
                      className="text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500">Y</label>
                    <Input
                      type="number"
                      value={selectedNodeData.y}
                      onChange={(e) => handleStyleUpdate('y', Number(e.target.value))}
                      className="text-sm"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Size</label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs text-gray-500">Width</label>
                    <Input
                      type="number"
                      value={selectedNodeData.width || 193}
                      onChange={(e) => handleStyleUpdate('width', Number(e.target.value))}
                      className="text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500">Height</label>
                    <Input
                      type="number"
                      value={selectedNodeData.height || 93}
                      onChange={(e) => handleStyleUpdate('height', Number(e.target.value))}
                      className="text-sm"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Border Radius</label>
                <Input
                  type="number"
                  placeholder="8"
                  className="text-sm"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Opacity</label>
                <div className="flex items-center gap-2">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    defaultValue="100"
                    className="flex-1"
                  />
                  <span className="text-sm text-gray-500 w-12">100%</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Layer</label>
                <div className="flex gap-2">
                  <button className="flex-1 px-3 py-2 bg-white border border-gray-300 text-sm rounded hover:bg-gray-50">
                    Send Back
                  </button>
                  <button className="flex-1 px-3 py-2 bg-white border border-gray-300 text-sm rounded hover:bg-gray-50">
                    Bring Forward
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-500 mt-8">
              <Info className="w-8 h-8 mx-auto mb-2" />
              <p className="text-sm">Select a node to edit advanced properties</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

const WorkflowCreationDialog: React.FC<{
  open: boolean;
  onClose: () => void;
  onConfirm: (name: string, description: string) => void;
}> = ({ open, onClose, onConfirm }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  const handleConfirm = () => {
    onConfirm(name, description);
    setName('');
    setDescription('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Workflow</DialogTitle>
          <DialogDescription>
            Enter a name and description for your new workflow to get started.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Workflow Name</label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter workflow name"
            />
          </div>
          <div>
            <label className="text-sm font-medium mb-2 block">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter workflow description"
              className="w-full border border-gray-300 rounded-md px-3 py-2 text-sm resize-none h-20"
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleConfirm} disabled={!name.trim()}>
              Create
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export const WorkflowEditor: React.FC<WorkflowEditorProps> = ({ 
  onClose, 
  currentWorkflow, 
  onWorkflowCreated, 
  onWorkflowSaved 
}) => {
  const [categories, setCategories] = useState(RULE_CATEGORIES);
  const [nodes, setNodes] = useState<WorkflowNode[]>([
    { 
      id: 'start', 
      type: 'start', 
      x: 100, 
      y: 50, 
      width: 193, 
      height: 93,
      backgroundColor: '#10b981',
      textColor: '#ffffff'
    },
    { 
      id: 'end', 
      type: 'end', 
      x: 100, 
      y: 400, 
      width: 193, 
      height: 93,
      backgroundColor: '#2563eb',
      textColor: '#ffffff'
    },
  ]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [connectingNode, setConnectingNode] = useState<string | null>(null);
  const [showWorkflowDialog, setShowWorkflowDialog] = useState(false);
  const [zoom, setZoom] = useState(100);
  
  // Simple zoom implementation without transforms that break drag and drop
  const handleZoomChange = useCallback((newZoom: number) => {
    setZoom(newZoom);
    toast.info(`Zoom set to ${newZoom}%`);
  }, []);

  const handleToggleCategory = useCallback((categoryId: string) => {
    setCategories((prev) =>
      prev.map((cat) =>
        cat.id === categoryId ? { ...cat, expanded: !cat.expanded } : cat
      )
    );
  }, []);

  const handleAddNode = useCallback((nodeData: Omit<WorkflowNode, 'id'>) => {
    const newNode: WorkflowNode = {
      ...nodeData,
      id: `node-${Date.now()}`,
    };
    setNodes((prev) => [...prev, newNode]);
  }, []);

  const handleDeleteNode = useCallback((id: string) => {
    setNodes((prev) => prev.filter((node) => node.id !== id));
    setConnections((prev) =>
      prev.filter((conn) => conn.from !== id && conn.to !== id)
    );
    if (selectedNode === id) setSelectedNode(null);
    if (connectingNode === id) setConnectingNode(null);
  }, [selectedNode, connectingNode]);

  const handleUpdateNode = useCallback((id: string, updates: Partial<WorkflowNode>) => {
    setNodes((prev) =>
      prev.map((node) => (node.id === id ? { ...node, ...updates } : node))
    );
  }, []);

  const handleSelectNode = useCallback((id: string | null) => {
    setSelectedNode(id);
    setConnectingNode(null);
  }, []);

  const handleStartConnection = useCallback((id: string) => {
    setConnectingNode(id);
    setSelectedNode(null);
    toast.info('Click on another node to create a connection');
  }, []);

  const handleCompleteConnection = useCallback((fromId: string, toId: string) => {
    if (fromId === toId) {
      toast.error('Cannot connect a node to itself');
      setConnectingNode(null);
      return;
    }

    // Check if connection already exists
    const existingConnection = connections.find(
      (conn) => (conn.from === fromId && conn.to === toId) || (conn.from === toId && conn.to === fromId)
    );

    if (existingConnection) {
      toast.error('Connection already exists');
      setConnectingNode(null);
      return;
    }

    const newConnection: Connection = {
      id: `connection-${Date.now()}`,
      from: fromId,
      to: toId,
    };

    setConnections((prev) => [...prev, newConnection]);
    setConnectingNode(null);
    toast.success('Connection created successfully');
  }, [connections]);

  const handleNewWorkflow = useCallback((name: string, description: string) => {
    // Reset the workflow state for new workflow
    setNodes([
      { 
        id: 'start', 
        type: 'start', 
        x: 100, 
        y: 50, 
        width: 193, 
        height: 93,
        backgroundColor: '#10b981',
        textColor: '#ffffff'
      },
      { 
        id: 'end', 
        type: 'end', 
        x: 100, 
        y: 400, 
        width: 193, 
        height: 93,
        backgroundColor: '#2563eb',
        textColor: '#ffffff'
      },
    ]);
    setConnections([]);
    setSelectedNode(null);
    setConnectingNode(null);
    
    onWorkflowCreated(name, description);
    toast.success(`New workflow "${name}" created`);
  }, [onWorkflowCreated]);

  const handleSaveWorkflow = useCallback(() => {
    if (!currentWorkflow) {
      toast.error('No workflow to save. Please create a workflow first.');
      return;
    }

    onWorkflowSaved({ nodes, connections });
    toast.success(`Workflow "${currentWorkflow.name}" saved successfully`);
  }, [nodes, connections, currentWorkflow, onWorkflowSaved]);

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="h-screen flex flex-col bg-white">
        {/* Breadcrumb */}
        <div className="px-4 py-2 border-b border-gray-200 bg-white">
          <nav className="text-sm text-gray-600 flex items-center gap-1">
            <button 
              onClick={onClose}
              className="hover:text-blue-600 transition-colors"
            >
              Home
            </button>
            <ChevronRight className="w-4 h-4" />
            <span>Workflow</span>
            <ChevronRight className="w-4 h-4" />
            <span className="font-medium text-gray-900">
              {currentWorkflow ? currentWorkflow.name : 'Create Workflow'}
            </span>
          </nav>
        </div>

        <TopControls 
          onNewWorkflow={() => setShowWorkflowDialog(true)}
          onSaveWorkflow={handleSaveWorkflow}
          zoom={zoom}
          onZoomChange={handleZoomChange}
          currentWorkflow={currentWorkflow}
        />

        <div className="flex flex-1 overflow-hidden">
          <LeftSidebar
            categories={categories}
            rules={SAMPLE_RULES}
            onToggleCategory={handleToggleCategory}
          />

          <div className="flex-1 flex flex-col overflow-hidden">
            <WorkflowCanvas
              nodes={nodes}
              connections={connections}
              selectedNode={selectedNode}
              connectingNode={connectingNode}
              onAddNode={handleAddNode}
              onDeleteNode={handleDeleteNode}
              onUpdateNode={handleUpdateNode}
              onSelectNode={handleSelectNode}
              onStartConnection={handleStartConnection}
              onCompleteConnection={handleCompleteConnection}
            />
          </div>

          <RightPanel 
            selectedNode={selectedNode}
            nodes={nodes}
            onUpdateNode={handleUpdateNode}
          />
        </div>

        <WorkflowCreationDialog
          open={showWorkflowDialog}
          onClose={() => setShowWorkflowDialog(false)}
          onConfirm={handleNewWorkflow}
        />
      </div>
    </DndProvider>
  );
};